function [datas,gt,mapping] = shuffle_data(raw_data,truelabel)
rand('twister',1)% Constructing fixed shuffle datasets
n_views = length(raw_data); 
for i =1 :n_views
   raw_data{i}= raw_data{i}'; %n*d^v
end
datas = {};
N = size(raw_data{1}, 1);
mapping = randperm(N);

for a = 1 : n_views 
    datas{a} = zeros(size(raw_data{a}));
    datas{a} = raw_data{a}(mapping,:);
end

for i =1 :n_views
   datas{i}= datas{i}'; 
end
gt = truelabel{1}(mapping);
end

