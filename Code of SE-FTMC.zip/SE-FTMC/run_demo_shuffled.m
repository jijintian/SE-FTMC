
clear;
clc

folder_now = pwd;
addpath([folder_now, '\funs']);
addpath([folder_now, '\dataset_Shuffled']);
dataname=["NGs"];
%% ==================== Load Datatset and Normalization ===================
for it_name = 1:length(dataname)
    %load(strcat('dataset/',dataname(it_name),'.mat'));
     load(strcat('dataset_shuffled/Shuffle_',dataname(it_name),'.mat'));
    %gt = truelabel{1}
    cls_num=length(unique(gt));
    X=data';
    nV = length(X);
    
    for v=1:nV
        [X{v}]=NormalizeData(X{v});
    end
    N =length(gt);
    %% ========================== Parameters Setting ==========================
    result=[];
    num = 0;
    max_val=0;
    record_num = 0;
    ii=0;
    delta =0;
    anchor=[cls_num,2*cls_num,3*cls_num,4*cls_num,5*cls_num,6*cls_num,7*cls_num,8*cls_num];
    %% ============================ Optimization ==============================
    for i_alpha = [0.001,0.005,0.01,0.05,0.1,0.5,1,5]
            for i_anchor = 1:1:8
                alpha =i_alpha;
                anc = anchor(i_anchor);
                ii=ii+1;
                tic;
                [y,Z] = Train_problem_anchor(X,cls_num,alpha,delta,anc);
                time = toc;
                [result(ii,:),res]=  ClusteringMeasure(gt, y);
                [result(ii,:),time]
                if result(ii,1) > max_val
                    max_val = result(ii,1);
                    record_result=result(ii,:);
                    record_time = time;
                end
%            end
        end
    end
    save('.\result\result_shuffle_'+dataname(it_name),'result','max_val','record_result','time')
end


