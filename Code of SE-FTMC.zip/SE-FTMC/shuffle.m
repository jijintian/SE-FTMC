clear;
clc

folder_now = pwd;
addpath([folder_now, '\funs']);
addpath([folder_now, '\dataset_Ordered']);
dataname=["NGs"];
%% ==================== Load Datatset and Normalization ===================
for it_name = 1:length(dataname)
    load(strcat('dataset/',dataname(it_name),'.mat'));
    
    [data,gt,mapping]=shuffle_data(data,truelabel);
    
    save('.\dataset_Shuffled\Shuffle_'+dataname(it_name),'data','gt','mapping');
end