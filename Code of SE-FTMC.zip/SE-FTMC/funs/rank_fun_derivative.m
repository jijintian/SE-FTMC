function y = rank_fun_derivative(x,delta,fun)
if fun ==1%%Geman
    y  = delta^2./(delta+x).^2;
else if fun == 2 %%Lapace
        y = exp(-x./delta)/delta;
    else if fun ==3 %%l_delta
            y= (delta+delta^2)./(delta+x).^2;
        end
    end
end
end
